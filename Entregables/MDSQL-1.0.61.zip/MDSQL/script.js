function isRemappingEnabledForClass(name) {
    return false;
}
function isObfuscatorEnabledForClass(name) {
    return true;
}