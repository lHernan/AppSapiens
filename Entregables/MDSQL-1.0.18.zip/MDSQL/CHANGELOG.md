# MDSQL

- Versión 1.0.0-SNAPSHOT (23/11/2022), Entregable-1.0.16

  Incidencias que se corrigen: 
  
  - Pantalla 4.6
  	- Se cambia método de compresión zip integrado de Java 7 por zip4j, por problema de traducción de rutas
  	- Se corrige selección de scripts a ejecutar
  	- Se corrige ejecución de scripts, si uno de ellos da error, no ejecutar el resto de orden inferior
  	- Se corrige ventana Ver Errores
  
  Código fuente.
  
 - Versión 1.0.0-SNAPSHOT (23/11/2022), Entregable-1.0.17
 
  Se incluye
  
  - Se agrega pantalla Ajustar log ejecución, se activa como consulta con el botón Ver log en pantalla Ejecutar scripts

  Incidencias que se corrigen: 
  
  - Se copian los archivos en lugar de moverlos
  - Se corrige selección de scripts a ejecutar cuando dan error o descuadrado
  - Se corrige ejecución de scripts, si uno de ellos da error, desmarcar el resto de orden inferior
  
  Código fuente.
  
 - Versión 1.0.0-SNAPSHOT (02/12/2022), Entregable-1.0.18

  Incidencias que se corrigen: 
  
  - Ajuste de pantalla detalle script
  - Se corrige selección de scripts a ejecutar cuando están pendientes
  - Se lectura del fichero de log
  - Se corrige rechazo de scripts
  
  Código fuente.
  
  
  
       
       
 
  
       
