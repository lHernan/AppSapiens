#!/bin/bash

java -jar mdsql-1.0.0-SNAPSHOT.jar
