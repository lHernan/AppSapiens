-----------------------------------------------------------
---MAPFRE DGTP - Modelo de datos ---- MDSQL v9 ------------
-----------------------------------------------------------
---Nº PETICIÓN:       PR-EJ
---FECHA:             07/11/2022 17:01:47
---SOLICITADA POR:    MARIPAM
---OBJETOS AFECTADOS: AAA
---PROYECTO:          MDSQL_SMD
---ENTORNO:           FD012
---REALIZADO POR:     MARIPAM
-----------------------------------------------------------
---TOTAL TABLAS      - CREADAS: 1, MODIFICADAS: 0, ELIMINADAS: 0
---TOTAL INDICES     - CREADOS: 0, MODIFICADOS: 0, ELIMINADOS: 0
---TOTAL VISTAS      - CREADAS: 0,                 ELIMINADAS: 0
---TOTAL VISTAS MAT. - CREADAS: 0, MODIFICADAS: 0, ELIMINADAS: 0
---TOTAL SECUENCIAS  - CREADAS: 0, MODIFICADAS: 0, ELIMINADAS: 0
---TOTAL TYPES       - CREADOS: 0,                 ELIMINADOS: 0
---TOTAL OBJETOS AFECTADOS: 1
---VARIABLES UTILIZADAS: &&USROWN
-----------------------------------------------------------
CREATE TABLE &&USROWN.AAA (
A NUMBER);

COMMENT ON TABLE &&USROWN.AAA IS 'TABLA &&USROWN.AAA';
COMMENT ON COLUMN &&USROWN.AAA.A IS 'COLUMNA A'; 
