create table smd_ld.aaa (
a number);
comment on table smd_ld.aaa is 'tabla smd_ld.aaa � n�';
comment on column smd_ld.aaa.a is 'columna a eeee  ��� � n�';
