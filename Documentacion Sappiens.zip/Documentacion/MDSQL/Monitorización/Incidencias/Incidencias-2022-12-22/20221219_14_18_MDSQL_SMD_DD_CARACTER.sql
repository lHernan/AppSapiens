-----------------------------------------------------------
---                      MDSQL v9              ------------
-----------------------------------------------------------
---Nº PETICIÓN:       RF-CARACTER
---FECHA:             19/12/2022 14:18:58
---SOLICITADA POR:    MARIPAM
---OBJETOS AFECTADOS: AAA
---PROYECTO:          MDSQL_SMD
---ENTORNO:           FD012
---REALIZADO POR:     MARIPAM
-----------------------------------------------------------
---TOTAL TABLAS      - CREADAS: 1, MODIFICADAS: 0, ELIMINADAS: 0
---TOTAL INDICES     - CREADOS: 0, MODIFICADOS: 0, ELIMINADOS: 0
---TOTAL VISTAS      - CREADAS: 0,                 ELIMINADAS: 0
---TOTAL VISTAS MAT. - CREADAS: 0, MODIFICADAS: 0, ELIMINADAS: 0
---TOTAL SECUENCIAS  - CREADAS: 0, MODIFICADAS: 0, ELIMINADAS: 0
---TOTAL TYPES       - CREADOS: 0,                 ELIMINADOS: 0
---TOTAL OBJETOS AFECTADOS: 1
---VARIABLES UTILIZADAS: &&USROWN
-----------------------------------------------------------
CREATE TABLE &&USROWN._LD.AAA (
A NUMBER);

COMMENT ON TABLE &&USROWN._LD.AAA IS 'TABLA &&USROWN._LD.AAA Ñ Nº';
COMMENT ON COLUMN &&USROWN._LD.AAA.A IS 'COLUMNA A EEEE  ÑÑÑ Á Nº';
